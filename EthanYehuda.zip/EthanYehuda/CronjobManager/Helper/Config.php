<?php

namespace EthanYehuda\CronjobManager\Helper;

class Config
{
    const PATH_CLEAN_RUNNING = "system/cron_job_manager/clean_running_schedule";
}