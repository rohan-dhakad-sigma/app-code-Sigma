<?php
/**
 * @category  Sigma
 * @package   Sigma_SearchResultsExtendGraphQl
 * @author    SigmaInfo Team
 * @copyright 2021 Sigma (https://www.sigmainfo.net/)
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Sigma_SearchResultsExtendGraphQl',
    __DIR__
);
