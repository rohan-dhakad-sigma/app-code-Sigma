<?php
/**
 * @category  Sigma
 * @package   Sigma_ProductSpecificationsGraphQl
 * @author    SigmaInfo Team
 * @copyright 2021 Sigma (https://www.sigmainfo.net/)
 */

use Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(ComponentRegistrar::MODULE, 'Sigma_ProductSpecificationsGraphQl', __DIR__);
